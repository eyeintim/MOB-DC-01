func repeat<Item>(item: Item, times: Int) -> [Item] {
    var result = [Item]()
    for i in 0..<times {
         result.append(item)
    }
    return result
}
repeat("knock", 4)
