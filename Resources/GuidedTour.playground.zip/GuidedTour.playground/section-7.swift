let implicitInteger = 70
let implicitDouble = 70.0
let explicitDouble: Double = 70
